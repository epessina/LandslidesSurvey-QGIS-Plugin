<h4 align="center">
<img src="https://github.com/epessina/LandslidesSurvey/blob/master/App/screens/logo.png" width="144" alt="Logo">
</h4>

# LandslidesSurvey QGIS Plugin

LandslidesSurvey QGIS Plugin is a plugin for QGIS 3 developed to easily retrieve all the data inserted through the
smartphone application [LandslidesSurvey](https://github.com/epessina/LandslidesSurvey). 

The plugin call the open RESTFul API of LandslidesSurvey and queries the database for all the landslides inserted.
The data can be filtered by the user using a vector layer and can be downloaded both in JSON format and as a Shapefile.


## Installation



## Usage




## License
[GNU GPLv3](https://choosealicense.com/licenses/gpl-3.0/#) © [Edoardo Pessina](edoardo2.pessina@mail.polimi.it)